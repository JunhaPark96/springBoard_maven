package springdi_assignment.tv_speaker.xmlver;

public interface SpeakerService {
	public void volumeup();
	public void volumedown();
	public String getBrand();
}
