package springdi_assignment.tv_speaker.xmlver;

public class XYZspeaker implements SpeakerService{

	public String getBrand() {
		return "XYZ 스피커";
	}

	public void volumeup() {
		System.out.println("볼륨 +1");
	}

	public void volumedown() {
		System.out.println("볼륨 -1");
	}
	
}
