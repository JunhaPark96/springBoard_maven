package springdi_assignment.tv_speaker.annover2;

public interface SpeakerService {
	public void volumeup();
	public void volumedown();
	public String getBrand();
}
