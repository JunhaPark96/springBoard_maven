package springdi_assignment.tv_speaker.annover3;

public interface TVService {
	public void turnon();
	public void turnoff();
	public void volumeup();
	public void volumedown();
	public void printSpeakerBrand();
}
