package springdi_assignment.tv_speaker.annover4;

public interface SpeakerService {
	public void volumeup();
	public void volumedown();
	public String getBrand();
}
