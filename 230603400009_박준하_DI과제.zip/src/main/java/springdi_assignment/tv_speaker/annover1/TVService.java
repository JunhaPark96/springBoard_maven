package springdi_assignment.tv_speaker.annover1;

public interface TVService {
	public void turnon();
	public void turnoff();
	public void volumeup();
	public void volumedown();
	public void printSpeakerBrand();
}
