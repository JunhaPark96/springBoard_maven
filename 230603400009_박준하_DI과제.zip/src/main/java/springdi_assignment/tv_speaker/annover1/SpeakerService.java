package springdi_assignment.tv_speaker.annover1;

public interface SpeakerService {
	public void volumeup();
	public void volumedown();
	public String getBrand();
}
