package springdi_assignment.tv_speaker.annover1;

public class ABCspeaker implements SpeakerService{
	public String getBrand() {
		return "ABC 스피커";
	}

	public void volumeup() {
		System.out.println("볼륨 +1");
	}

	public void volumedown() {
		System.out.println("볼륨 -1");
	}

}
