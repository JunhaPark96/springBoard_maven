package springdi_assignment.calculator.xmlver;

public interface Calculator {
	public int calculate(int n1, int n2);
}
