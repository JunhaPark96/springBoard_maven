package springdi_assignment.calculator.annoVer2;

public interface Calculator {
	public int calculate(int n1, int n2);
}
