package springdi_assignment.calculator.annoVer1;

public interface Calculator {
	public int calculate(int n1, int n2);
}
